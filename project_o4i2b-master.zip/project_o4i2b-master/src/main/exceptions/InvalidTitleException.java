package exceptions;

public class InvalidTitleException extends Throwable {
}
